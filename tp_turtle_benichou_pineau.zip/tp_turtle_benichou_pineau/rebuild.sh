echo "Rebuilding..."
catkin_make
source devel/setup.bash
echo "Done!"