# ROS_TutleBot_discovery

## Contributors

* Charlotte Pineau
* William Bénichou